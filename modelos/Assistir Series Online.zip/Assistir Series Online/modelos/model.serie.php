<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    	include '../autoload.php';

$acao=val_input::sani_string('acao');

	$descricao = val_input::sani_string('descricao');
	$data_criacao = val_input::sani_string('data_criacao');

	//Instância da classe:
	$Serie = new Serie($connection);
switch ($acao) {    case 'inserir':
echo $Serie->salvarDados($descricao,$data_criacao) > 0 ? '1':'0';
      break;   case 'excluir':
$id= val_input::val_int('id');
     echo $Serie->excluir_por_id($id) > 0 ? '1' : '0';      break;}}
