<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    	include '../autoload.php';

$acao=val_input::sani_string('acao');

	$descricao = val_input::sani_string('descricao');
	$data_criacao = val_input::sani_string('data_criacao');
	$data_disponibilizacao = val_input::sani_string('data_disponibilizacao');
	$temporada_id = val_input::sani_string('temporada_id');

	//Instância da classe:
	$Espisodios = new Espisodios($connection);
switch ($acao) {    case 'inserir':
echo $Espisodios->salvarDados($descricao,$data_criacao,$data_disponibilizacao,$temporada_id) > 0 ? '1':'0';
      break;   case 'excluir':
$id= val_input::val_int('id');
     echo $Espisodios->excluir_por_id($id) > 0 ? '1' : '0';      break;}}
