<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    	include '../autoload.php';

$acao=val_input::sani_string('acao');

	$temporada = val_input::sani_string('temporada');
	$serie_codigo = val_input::sani_string('serie_codigo');
	$data_criacao = val_input::sani_string('data_criacao');
	$num_episodios = val_input::sani_string('num_episodios');

	//Instância da classe:
	$Temporadas = new Temporadas($connection);
switch ($acao) {    case 'inserir':
echo $Temporadas->salvarDados($temporada,$serie_codigo,$data_criacao,$num_episodios) > 0 ? '1':'0';
      break;   case 'excluir':
$id= val_input::val_int('id');
     echo $Temporadas->excluir_por_id($id) > 0 ? '1' : '0';      break;}}
