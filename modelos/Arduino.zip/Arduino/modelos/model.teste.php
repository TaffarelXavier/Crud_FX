<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    	include '../autoload.php';

$acao=val_input::sani_string('acao');

	$nome = val_input::sani_string('nome');
	$data = val_input::sani_string('data');

	//Instância da classe:
	$teste = new Teste($connection);
switch ($acao) {    case 'inserir':
echo $teste->salvarDados($nome,$data) > 0 ? '1':'0';
      break;   case 'excluir':
$id= val_input::val_int('id');
     echo $teste->excluir_por_id($id) > 0 ? '1' : '0';      break;}}
